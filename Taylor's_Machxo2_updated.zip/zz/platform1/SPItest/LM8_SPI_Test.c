#include "MicoUART.h"
#include "DDStructs.h"
#include "MicoSPIFlash.h"
#include "MicoGPIO.h"
#include "MicoUtils.h"

unsigned long address = 0x00000010;
unsigned char *Flash_address = (unsigned char*) 0x01000000;


static unsigned char GetCharacter(MicoUartCtx_t *pUart)
{
  unsigned char c;
  MicoUart_getC(pUart, &c);
  return(c);
}

static void SendCharacter(MicoUartCtx_t *pUart, unsigned char c)
{
  MicoUart_putC(pUart, c);
	return;
}

/*************************
 * USER-MAIN ENTRY POINT *
 *************************/
int main (void)
{
	unsigned char iValue = 0x1;
	unsigned char SPIin;
	unsigned char SPIout;
	
	/* gpio instance name is "LED" */
	MicoGPIOCtx_t *leds = &gpio_LED;
	/* SPI flash instance name is "SPIFLASH" */
	MicoSPIFlashCtx_t *spiFlash = &spi_flash_SPIFlash;
	/* UART instance name is "uart" */
	MicoUartCtx_t *uart = &uart_core_uart;
	
	

	  iValue = 0x2;
	  unsigned char iShiftLeft = 1;

	   /* Fetch GPIO instance named "LED" */

	    if(leds == 0){
	        return(0);
	    }

		 //Erase the SPI
		MICO_SPI_BLOCK_ERASE_TYPE1 (spiFlash->control_base, (unsigned long)0x00000000);// 4Kbytes erase

		MicoSleepMilliSecs(200);

		/* scroll the LEDs, every 100 msecs forever */
		while(1){



			MICO_GPIO_WRITE_DATA_BYTE0 (leds->base, iValue);


			SPIin = GetCharacter (uart);
			*(Flash_address + address) = SPIin;
			switch(SPIin) {

				case 0x1  :
					iValue = 0x02;
					break;

				case 0x2  :
					iValue = 0x00;
					break;

				default :
					iValue = 0x01;
					break;
			}


	    /*
	     * Wait for some time since the UART baud rate is much slower
	     * than the CPU clock speed
	     */
	    MicoSleepMilliSecs (100);

	    SPIout = *(Flash_address + address);

	    SendCharacter (uart, SPIout);
		MicoSleepMilliSecs (100);



			if(iShiftLeft == 1){
				iValue = iValue << 1;
				if(iValue == 0x10){
					iValue = 0x4;
					iShiftLeft = 0;
				}
			}else{
				iValue = iValue >> 1;
				if(iValue == 0){
					iValue = 0x02;
					iShiftLeft = 1;
				}
			}
		}

	return(0);
}
