#include "DDStructs.h"
#include "MicoUtils.h"
#include "MicoGPIO.h"
#include "MicoUART.h"


static unsigned char GetCharacter(MicoUartCtx_t *pUart)
{
  unsigned char c;
  MicoUart_getC(pUart, &c);
  return(c);
}

static void SendCharacter(MicoUartCtx_t *pUart, unsigned char c)
{
  MicoUart_putC(pUart, c);
	return;
}

int main(void){
	unsigned char c;
	MicoUartCtx_t *uart = &uart_core_uart;
	// MicoUart_setRate (uart, 9600);

  unsigned char iValue = 0x1;
  unsigned char iShiftLeft = 1;

   /* Fetch GPIO instance named "LED" */
	MicoGPIOCtx_t *leds = &gpio_LED;
    if(leds == 0){
        return(0);
    }

	/* scroll the LEDs, every 100 msecs forever */
	while(1){
		MICO_GPIO_WRITE_DATA_BYTE0 (leds->base, iValue);

		c = GetCharacter (uart);

		switch(c) {

			case 0x1  :
				iValue = 0x02;
				break;

			case 0x2  :
				iValue = 0x00;
				break;

			default :
				iValue = 0x01;
				break;
		}





    /*
     * Wait for some time since the UART baud rate is much slower
     * than the CPU clock speed
     */
    MicoSleepMilliSecs (100);

    SendCharacter (uart, c);
		MicoSleepMilliSecs (100);

		SendCharacter (uart, 'F');
		MicoSleepMilliSecs (100);

		SendCharacter (uart, 'U');
		MicoSleepMilliSecs (100);

		SendCharacter (uart, 'C');
		MicoSleepMilliSecs (100);

		SendCharacter (uart, 'K');
		MicoSleepMilliSecs (100);



		// MicoSleepMilliSecs(10000);

		if(iShiftLeft == 1){
			iValue = iValue << 1;
			if(iValue == 0x10){
				iValue = 0x4;
				iShiftLeft = 0;
			}
		}else{
			iValue = iValue >> 1;
			if(iValue == 0){
				iValue = 0x02;
				iShiftLeft = 1;
			}
		}
	}

    /* all done */
    return(0);
}
